<?php
/**
 * Plugin Name: Mira — Provador Virtual IA
 * Description: Probador virtual con IA para tiendas WooCommerce. Sistema SaaS con créditos, Stripe, personalización visual y soporte para ropa y accesorios.
 * Version: 17.0.0
 * Author: HUnix Design
 * Text Domain: mira-provador
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'MIRA_VERSION', '17.0.0' );
define( 'MIRA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'MIRA_PLUGIN_URL', plugins_url( '', __FILE__ ) );

// ── Configuración inyectada al generar el ZIP por cliente ──
if ( ! defined( 'MIRA_EMBEDDED_LICENSE' ) )    define( 'MIRA_EMBEDDED_LICENSE',    '' );
if ( ! defined( 'MIRA_EMBEDDED_CREDITS' ) )    define( 'MIRA_EMBEDDED_CREDITS',    5  );
if ( ! defined( 'MIRA_MAKE_CREDITS_SUB' ) )    define( 'MIRA_MAKE_CREDITS_SUB',    '' ); // webhook Make restar
if ( ! defined( 'MIRA_GSHEET_ID' ) )           define( 'MIRA_GSHEET_ID',           '' ); // ID Google Sheet central
if ( ! defined( 'MIRA_GSHEET_SA_JSON_B64' ) )  define( 'MIRA_GSHEET_SA_JSON_B64',  '' ); // Service Account base64

// Cargar mira-config.php si existe (generado al descargar el ZIP)
$_mira_cfg = MIRA_PLUGIN_DIR . 'mira-config.php';
if ( file_exists( $_mira_cfg ) && ! defined( 'MIRA_CONFIG_LOADED' ) ) {
    define( 'MIRA_CONFIG_LOADED', true );
    include_once $_mira_cfg;
}

// ==========================================
// GOOGLE SHEETS — LECTURA DIRECTA (0 ops Make)
// ==========================================

function mira_gsheet_token() {
    $sa_json = get_option( 'mira_gsheet_sa_json', '' );
    if ( empty( $sa_json ) ) return '';
    $sa = json_decode( $sa_json, true );
    if ( ! $sa || empty( $sa['private_key'] ) ) return '';

    $now  = time();
    $head = rtrim( strtr( base64_encode( json_encode(['alg'=>'RS256','typ'=>'JWT']) ), '+/', '-_' ), '=' );
    $pay  = rtrim( strtr( base64_encode( json_encode([
        'iss'   => $sa['client_email'],
        'scope' => 'https://www.googleapis.com/auth/spreadsheets.readonly',
        'aud'   => 'https://oauth2.googleapis.com/token',
        'iat'   => $now, 'exp' => $now + 3600,
    ]) ), '+/', '-_' ), '=' );

    $sig = '';
    $pk  = openssl_pkey_get_private( $sa['private_key'] );
    if ( ! $pk ) return '';
    openssl_sign( $head . '.' . $pay, $sig, $pk, 'SHA256' );
    $jwt = $head . '.' . $pay . '.' . rtrim( strtr( base64_encode($sig), '+/', '-_' ), '=' );

    $r = wp_remote_post( 'https://oauth2.googleapis.com/token', [
        'timeout' => 10,
        'body'    => ['grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $jwt],
    ]);
    if ( is_wp_error($r) ) return '';
    $b = json_decode( wp_remote_retrieve_body($r), true );
    return $b['access_token'] ?? '';
}

function mira_gsheet_read( $license ) {
    if ( empty($license) ) return false;
    $sheet_id = get_option( 'mira_gsheet_id', '' );
    if ( empty($sheet_id) ) return false;

    $token = mira_gsheet_token();
    if ( empty($token) ) return false;

    $r = wp_remote_get(
        'https://sheets.googleapis.com/v4/spreadsheets/' . $sheet_id . '/values/' . rawurlencode('A:L'),
        [ 'timeout' => 8, 'headers' => ['Authorization' => 'Bearer ' . $token] ]
    );
    if ( is_wp_error($r) || wp_remote_retrieve_response_code($r) !== 200 ) return false;

    $rows = json_decode( wp_remote_retrieve_body($r), true )['values'] ?? [];
    foreach ( $rows as $i => $row ) {
        if ( $i === 0 ) continue;
        if ( trim($row[1] ?? '') !== trim($license) ) continue;

        $total  = (int)($row[5] ?? 5);
        $used   = (int)($row[6] ?? 0);
        $extra  = (int)($row[8] ?? 0);
        $plan   = $row[3] ?? '';
        $sub    = ( ! empty($row[7]) && strtotime($row[7]) < time() ) ? 'active' : 'trialing';
        $left   = max(0, ($total - $used) + $extra);

        return [
            'has_credits'       => $left > 0,
            'credits_remaining' => $left,
            'credits_total'     => $total,
            'credits_used'      => $used,
            'credits_extra'     => $extra,
            'subscription'      => $sub,
            'plan'              => $plan,
            'source'            => 'gsheet',
        ];
    }
    return false;
}

// ==========================================
// ACTIVACIÓN / DESACTIVACIÓN
// ==========================================
register_activation_hook( __FILE__, 'mira_activate' );
function mira_activate() {
    $credits = defined('MIRA_EMBEDDED_CREDITS') ? (int)MIRA_EMBEDDED_CREDITS : 5;
    update_option( 'mira_free_tries_total', $credits );
    update_option( 'mira_paid_credits', 0 );
    update_option( 'mira_stat_tries', 0 );
    update_option( 'mira_activation_date', current_time( 'mysql' ) );

    if ( defined('MIRA_EMBEDDED_LICENSE') && MIRA_EMBEDDED_LICENSE !== '' ) {
        update_option( 'mira_license_key', MIRA_EMBEDDED_LICENSE );
        update_option( 'mira_subscription_status', 'trialing' );
    }
    if ( defined('MIRA_MAKE_CREDITS_SUB') && MIRA_MAKE_CREDITS_SUB !== '' )
        update_option( 'mira_make_credits_sub', MIRA_MAKE_CREDITS_SUB );
    if ( defined('MIRA_GSHEET_ID') && MIRA_GSHEET_ID !== '' )
        update_option( 'mira_gsheet_id', MIRA_GSHEET_ID );
    if ( defined('MIRA_GSHEET_SA_JSON_B64') && MIRA_GSHEET_SA_JSON_B64 !== '' )
        update_option( 'mira_gsheet_sa_json', base64_decode(MIRA_GSHEET_SA_JSON_B64) );

    update_option( 'mira_show_wizard', 1 );
}

// ==========================================
// WIZARD DE CONFIGURACIÓN INICIAL
// ==========================================
add_action( 'admin_notices', 'mira_show_setup_wizard' );
function mira_show_setup_wizard() {
    if ( ! get_option( 'mira_show_wizard' ) ) return;
    if ( ! current_user_can( 'manage_options' ) ) return;
    $page = isset( $_GET['page'] ) ? $_GET['page'] : '';
    if ( $page === 'mira-wizard' ) return;
    ?>
    <div class="notice notice-info" style="border-left:4px solid #8b7355; padding:15px; display:flex; align-items:center; gap:15px;">
        <div style="font-size:28px;">🪄</div>
        <div>
            <strong>Mira está instalado.</strong> Configura tu clave de API y conecta Stripe en el asistente de configuración.
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=mira-wizard' ) ); ?>" class="button button-primary" style="margin-left:10px;">Iniciar configuración →</a>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=mira-wizard&skip=1' ) ); ?>" style="margin-left:8px; color:#999; font-size:12px;">Omitir</a>
        </div>
    </div>
    <?php
}

// ==========================================
// ADMIN INIT — sincronizar créditos desde Google Sheets al abrir panel
// ==========================================
add_action( 'admin_init', function() {
    if ( ! current_user_can('manage_options') ) return;
    $page = $_GET['page'] ?? '';
    if ( strpos($page, 'mira-') === false ) return;

    $license = get_option('mira_license_key', '');
    if ( empty($license) ) return;

    $data = mira_gsheet_read($license);
    if ( $data !== false ) {
        update_option('mira_free_tries_total',   $data['credits_total']);
        update_option('mira_paid_credits',        $data['credits_extra']);
        update_option('mira_subscription_status', $data['subscription']);
    }
});

// ==========================================
// MENÚ ADMIN
// ==========================================
add_action( 'admin_menu', 'mira_admin_menu' );
function mira_admin_menu() {
    add_menu_page( 'Mira IA', 'Mira IA', 'manage_options', 'mira-dashboard', 'mira_dashboard_page', 'dashicons-camera', 25 );
    add_submenu_page( 'mira-dashboard', 'Panel', 'Panel', 'manage_options', 'mira-dashboard', 'mira_dashboard_page' );
    add_submenu_page( 'mira-dashboard', 'Configuración', 'Configuración', 'manage_options', 'mira-settings', 'mira_settings_page' );
    add_submenu_page( 'mira-dashboard', 'Diseño', 'Diseño', 'manage_options', 'mira-design', 'mira_design_page' );
    add_submenu_page( 'mira-dashboard', 'Créditos', 'Créditos', 'manage_options', 'mira-credits', 'mira_credits_page' );
    add_submenu_page( 'mira-dashboard', 'Asistente', 'Asistente', 'manage_options', 'mira-wizard', 'mira_wizard_page' );
}

// ==========================================
// PANEL PRINCIPAL (DASHBOARD)
// ==========================================
function mira_dashboard_page() {
    $tries_used   = (int) get_option( 'mira_stat_tries', 0 );
    $users        = (int) get_option( 'mira_stat_users', 0 );
    $free_total   = (int) get_option( 'mira_free_tries_total', 7 );
    $paid_credits = (int) get_option( 'mira_paid_credits', 0 );
    $total_left   = max( 0, $free_total - min( $tries_used, $free_total ) ) + $paid_credits;
    $sub_status   = get_option( 'mira_subscription_status', 'none' );
    $sub_plan     = get_option( 'mira_subscription_plan', '' );

    $status_badge = '';
    switch ( $sub_status ) {
        case 'active':
            $status_badge = '<span style="background:#22c55e; color:#fff; padding:3px 10px; border-radius:20px; font-size:12px;">✓ Activa — ' . esc_html( $sub_plan ) . '</span>';
            break;
        case 'trialing':
            $status_badge = '<span style="background:#f59e0b; color:#fff; padding:3px 10px; border-radius:20px; font-size:12px;">⏳ Prueba gratuita</span>';
            break;
        default:
            $status_badge = '<span style="background:#ef4444; color:#fff; padding:3px 10px; border-radius:20px; font-size:12px;">⚠️ Sin suscripción</span>';
    }
    ?>
    <div class="wrap">
        <h1 style="display:flex; align-items:center; gap:10px;">
            <span style="background:#1a1917; color:#fff; padding:6px 12px; border-radius:8px; font-size:18px;">M</span>
            Mira IA — Panel
            <?php echo $status_badge; ?>
        </h1>
        
        <!-- Tarjetas de estadísticas -->
        <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(180px,1fr)); gap:15px; margin:20px 0;">
            <?php
            $cards = [
                [ '🎯', 'Pruebas realizadas', $tries_used, '#8b7355' ],
                [ '👤', 'Perfiles registrados', $users, '#1a1917' ],
                [ '💳', 'Créditos restantes', $total_left, $total_left < 10 ? '#ef4444' : '#22c55e' ],
                [ '🆓', 'Pruebas gratuitas',  max(0, $free_total - min($tries_used, $free_total)), '#6366f1' ],
            ];
            foreach ( $cards as $c ) {
                echo '<div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:20px; text-align:center;">';
                echo '<div style="font-size:28px; margin-bottom:8px;">' . $c[0] . '</div>';
                echo '<div style="font-size:28px; font-weight:700; color:' . $c[3] . ';">' . number_format($c[2]) . '</div>';
                echo '<div style="font-size:12px; color:#6b7280; margin-top:4px;">' . $c[1] . '</div>';
                echo '</div>';
            }
            ?>
        </div>

        <?php if ( $total_left < 5 ) : ?>
        <div style="background:#fef3c7; border:1px solid #fcd34d; border-radius:8px; padding:15px; margin-bottom:20px;">
            ⚠️ Te quedan <strong><?php echo $total_left; ?> créditos</strong>. 
            <a href="<?php echo admin_url('admin.php?page=mira-credits'); ?>">Recarga créditos →</a> o 
            <a href="<?php echo admin_url('admin.php?page=mira-settings'); ?>">activa tu suscripción →</a>
        </div>
        <?php endif; ?>

        <!-- Accesos rápidos -->
        <div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(200px,1fr)); gap:12px; margin-top:10px;">
            <?php
            $links = [
                [ 'mira-settings', '🔌', 'Webhooks & API', 'Conecta Make y configura integraciones' ],
                [ 'mira-design',   '🎨', 'Diseño Visual',  'Personaliza colores, fuentes y textos' ],
                [ 'mira-credits',  '💳', 'Créditos',       'Gestiona suscripción y packs extra' ],
                [ 'mira-wizard',   '🪄', 'Asistente',      'Reconfigura el plugin paso a paso' ],
            ];
            foreach ( $links as $l ) {
                echo '<a href="' . admin_url('admin.php?page=' . $l[0]) . '" style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:16px; text-decoration:none; color:inherit; display:block; transition:box-shadow .2s;" onmouseover="this.style.boxShadow=\'0 4px 12px rgba(0,0,0,0.1)\'" onmouseout="this.style.boxShadow=\'none\'">';
                echo '<div style="font-size:22px; margin-bottom:6px;">' . $l[1] . '</div>';
                echo '<div style="font-weight:600; color:#1a1917;">' . $l[2] . '</div>';
                echo '<div style="font-size:12px; color:#6b7280; margin-top:3px;">' . $l[3] . '</div>';
                echo '</a>';
            }
            ?>
        </div>
    </div>
    <?php
}

// ==========================================
// PÁGINA DE CONFIGURACIÓN (WEBHOOKS + STRIPE)
// ==========================================
function mira_settings_page() {
    if ( isset( $_POST['mira_save_settings'] ) ) {
        check_admin_referer( 'mira_settings_nonce', 'mira_nonce' );
        $fields = [
            'mira_webhook_reg'    => 'sanitize_url',
            'mira_webhook_gen'    => 'sanitize_url',
            'mira_stripe_pk'      => 'sanitize_text_field',
            'mira_stripe_sk'      => 'sanitize_text_field',
            'mira_stripe_webhook_secret' => 'sanitize_text_field',
            'mira_dalle_key'      => 'sanitize_text_field',
            'mira_replicate_key'  => 'sanitize_text_field',
        ];
        foreach ( $fields as $key => $fn ) {
            if ( isset( $_POST[$key] ) ) {
                update_option( $key, $fn( $_POST[$key] ) );
            }
        }
        echo '<div class="notice notice-success"><p>✅ Configuración guardada.</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>🔌 Configuración — Webhooks & APIs</h1>
        <form method="post">
            <?php wp_nonce_field( 'mira_settings_nonce', 'mira_nonce' ); ?>
            
            <div style="display:grid; gap:20px; max-width:800px;">
                
                <!-- WEBHOOKS MAKE -->
                <div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:24px;">
                    <h3 style="margin-top:0;">🔗 Make (Integromat) — Webhooks</h3>
                    <table class="form-table">
                        <tr>
                            <th><label>Webhook de Registro</label></th>
                            <td>
                                <input type="url" name="mira_webhook_reg" value="<?php echo esc_attr(get_option('mira_webhook_reg')); ?>" class="large-text" placeholder="https://hook.eu1.make.com/...">
                                <p class="description">Se activa cuando un cliente sube su foto (evento: registro).</p>
                            </td>
                        </tr>
                        <tr>
                            <th><label>Webhook de Generación</label></th>
                            <td>
                                <input type="url" name="mira_webhook_gen" value="<?php echo esc_attr(get_option('mira_webhook_gen')); ?>" class="large-text" placeholder="https://hook.eu1.make.com/...">
                                <p class="description">Se activa para procesar el try-on con IA (evento: solicitud). Distingue automáticamente entre ropa y accesorios.</p>
                            </td>
                        </tr>
                    </table>
                    <div style="background:#f0f9ff; border-radius:8px; padding:12px; margin-top:12px; font-size:13px;">
                        <strong>Payload enviado a Make:</strong><br>
                        <code>{ type, phone, name, product_image, product_link, <strong>product_category, category_type</strong> }</code><br>
                        <em>• category_type puede ser "clothing", "glasses", "jewelry", "bag" u "other"</em>
                    </div>
                </div>

                <!-- STRIPE -->
                <div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:24px;">
                    <h3 style="margin-top:0;">💳 Stripe — Pagos y Suscripciones</h3>
                    <div style="background:#f0fdf4; border-radius:8px; padding:12px; margin-bottom:16px; font-size:13px;">
                        <strong>Configuración del Webhook en Stripe:</strong><br>
                        URL: <code><?php echo esc_url( rest_url( 'mira/v1/stripe-webhook' ) ); ?></code><br>
                        Eventos: <code>checkout.session.completed</code>, <code>customer.subscription.updated</code>, <code>customer.subscription.deleted</code>
                    </div>
                    <table class="form-table">
                        <tr>
                            <th><label>Clave Pública (pk_live_...)</label></th>
                            <td><input type="text" name="mira_stripe_pk" value="<?php echo esc_attr(get_option('mira_stripe_pk')); ?>" class="large-text" placeholder="pk_live_..."></td>
                        </tr>
                        <tr>
                            <th><label>Clave Secreta (sk_live_...)</label></th>
                            <td><input type="password" name="mira_stripe_sk" value="<?php echo esc_attr(get_option('mira_stripe_sk')); ?>" class="large-text" placeholder="sk_live_..."></td>
                        </tr>
                        <tr>
                            <th><label>Webhook Secret (whsec_...)</label></th>
                            <td>
                                <input type="password" name="mira_stripe_webhook_secret" value="<?php echo esc_attr(get_option('mira_stripe_webhook_secret')); ?>" class="large-text" placeholder="whsec_...">
                                <p class="description">Obtenlo en el panel de Stripe → Webhooks → Firma.</p>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- IA APIs -->
                <div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:24px;">
                    <h3 style="margin-top:0;">🤖 APIs de IA (Optimización de Imagen)</h3>
                    <p style="color:#6b7280; font-size:13px;">Opcionales: permiten optimizar las fotos de producto antes de enviarlas a Make.</p>
                    <table class="form-table">
                        <tr>
                            <th><label>OpenAI / DALL-E 3 Key</label></th>
                            <td><input type="password" name="mira_dalle_key" value="<?php echo esc_attr(get_option('mira_dalle_key')); ?>" class="large-text" placeholder="sk-..."></td>
                        </tr>
                        <tr>
                            <th><label>Replicate API Token</label></th>
                            <td>
                                <input type="password" name="mira_replicate_key" value="<?php echo esc_attr(get_option('mira_replicate_key')); ?>" class="large-text" placeholder="r8_...">
                                <p class="description">Para Stable Diffusion / ControlNet (accesorios y gafas).</p>
                            </td>
                        </tr>
                    </table>
                </div>

            </div>
            <p style="margin-top:20px;"><input type="submit" name="mira_save_settings" class="button button-primary button-large" value="💾 Guardar Configuración"></p>
        </form>
    </div>
    <?php
}

// ==========================================
// PÁGINA DE DISEÑO VISUAL (CUSTOMIZER)
// ==========================================
function mira_design_page() {
    if ( isset( $_POST['mira_save_design'] ) ) {
        check_admin_referer( 'mira_design_nonce', 'mira_design_nonce_field' );
        $fields = [
            'mira_color_brand'   => 'sanitize_hex_color',
            'mira_color_text'    => 'sanitize_hex_color',
            'mira_color_accent'  => 'sanitize_hex_color',
            'mira_btn_radius'    => 'intval',
            'mira_btn_txt'       => 'sanitize_text_field',
            'mira_float_pos'     => 'sanitize_text_field',
            'mira_float_title'   => 'sanitize_text_field',
            'mira_float_sub'     => 'sanitize_text_field',
            'mira_instr_text'    => 'wp_kses_post',
            'mira_policy_text'   => 'sanitize_text_field',
            'mira_font_family'   => 'sanitize_text_field',
        ];
        foreach ( $fields as $key => $fn ) {
            if ( isset( $_POST[$key] ) ) {
                update_option( $key, $fn( $_POST[$key] ) );
            }
        }
        echo '<div class="notice notice-success"><p>✅ Diseño guardado.</p></div>';
    }

    $brand   = get_option( 'mira_color_brand', '#1a1917' );
    $text    = get_option( 'mira_color_text', '#FFFFFF' );
    $accent  = get_option( 'mira_color_accent', '#8b7355' );
    $radius  = get_option( 'mira_btn_radius', 8 );
    $btn_txt = get_option( 'mira_btn_txt', '✨ PROBAR ESTE LOOK' );
    $pos     = get_option( 'mira_float_pos', 'right' );
    $f_title = get_option( 'mira_float_title', 'Mi Perfil IA' );
    $f_sub   = get_option( 'mira_float_sub', 'Gestionar foto' );
    $instr   = get_option( 'mira_instr_text', "1. Sube tu foto frontal.\n2. Pulsa Guardar Perfil.\n3. Pruébate cualquier prenda." );
    $policy  = get_option( 'mira_policy_text', 'Acepto el uso de mi imagen con fines de prueba virtual.' );
    $font    = get_option( 'mira_font_family', 'inherit' );
    ?>
    <div class="wrap">
        <h1>🎨 Diseño Visual</h1>
        <div style="display:grid; grid-template-columns:1fr 350px; gap:24px; max-width:1100px;">
            
            <form method="post">
                <?php wp_nonce_field( 'mira_design_nonce', 'mira_design_nonce_field' ); ?>
                
                <!-- COLORES -->
                <div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:24px; margin-bottom:20px;">
                    <h3 style="margin-top:0;">🎨 Colores</h3>
                    <table class="form-table">
                        <tr>
                            <th>Color principal (fondo botón)</th>
                            <td><input type="color" name="mira_color_brand" value="<?php echo esc_attr($brand); ?>"> <code><?php echo esc_html($brand); ?></code></td>
                        </tr>
                        <tr>
                            <th>Color texto botón</th>
                            <td><input type="color" name="mira_color_text" value="<?php echo esc_attr($text); ?>"> <code><?php echo esc_html($text); ?></code></td>
                        </tr>
                        <tr>
                            <th>Color acento (links, dots)</th>
                            <td><input type="color" name="mira_color_accent" value="<?php echo esc_attr($accent); ?>"> <code><?php echo esc_html($accent); ?></code></td>
                        </tr>
                    </table>
                </div>

                <!-- BOTÓN -->
                <div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:24px; margin-bottom:20px;">
                    <h3 style="margin-top:0;">🔘 Botón Principal</h3>
                    <table class="form-table">
                        <tr>
                            <th>Texto del botón</th>
                            <td><input type="text" name="mira_btn_txt" value="<?php echo esc_attr($btn_txt); ?>" class="large-text"></td>
                        </tr>
                        <tr>
                            <th>Radio de borde (px)</th>
                            <td>
                                <input type="range" name="mira_btn_radius" min="0" max="50" value="<?php echo esc_attr($radius); ?>" oninput="document.getElementById('mira_radius_val').textContent=this.value">
                                <span id="mira_radius_val"><?php echo esc_html($radius); ?></span>px
                                <p class="description">0 = cuadrado · 50 = píldora</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Tipografía</th>
                            <td>
                                <select name="mira_font_family">
                                    <?php
                                    $fonts = [ 'inherit' => 'Heredar del tema', 'Georgia, serif' => 'Georgia (serif)', 'Helvetica, sans-serif' => 'Helvetica', "'Playfair Display', serif" => 'Playfair Display', "'Montserrat', sans-serif" => 'Montserrat', "'Lato', sans-serif" => 'Lato' ];
                                    foreach ( $fonts as $val => $label ) {
                                        echo '<option value="' . esc_attr($val) . '"' . selected($font, $val, false) . '>' . esc_html($label) . '</option>';
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                    </table>
                </div>

                <!-- BOTÓN FLOTANTE -->
                <div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:24px; margin-bottom:20px;">
                    <h3 style="margin-top:0;">💬 Botón Flotante</h3>
                    <table class="form-table">
                        <tr>
                            <th>Posición</th>
                            <td>
                                <select name="mira_float_pos">
                                    <option value="right" <?php selected($pos,'right'); ?>>Derecha</option>
                                    <option value="left" <?php selected($pos,'left'); ?>>Izquierda</option>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>Título</th>
                            <td><input type="text" name="mira_float_title" value="<?php echo esc_attr($f_title); ?>" class="large-text"></td>
                        </tr>
                        <tr>
                            <th>Subtítulo</th>
                            <td><input type="text" name="mira_float_sub" value="<?php echo esc_attr($f_sub); ?>" class="large-text"></td>
                        </tr>
                    </table>
                </div>

                <!-- TEXTOS LEGALES -->
                <div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:24px; margin-bottom:20px;">
                    <h3 style="margin-top:0;">📝 Instrucciones y Legal</h3>
                    <table class="form-table">
                        <tr>
                            <th>Instrucciones</th>
                            <td><textarea name="mira_instr_text" rows="4" class="large-text"><?php echo esc_textarea($instr); ?></textarea></td>
                        </tr>
                        <tr>
                            <th>Texto legal (checkbox)</th>
                            <td><input type="text" name="mira_policy_text" value="<?php echo esc_attr($policy); ?>" class="large-text"></td>
                        </tr>
                    </table>
                </div>

                <input type="submit" name="mira_save_design" class="button button-primary button-large" value="💾 Guardar Diseño">
            </form>

            <!-- PREVIEW -->
            <div style="position:sticky; top:32px;">
                <div style="background:#f9f9f9; border:1px solid #e5e7eb; border-radius:10px; padding:20px;">
                    <h4 style="margin-top:0; text-align:center; color:#6b7280;">Vista Previa</h4>
                    <div style="background:#fff; border-radius:8px; padding:16px; box-shadow:0 2px 10px rgba(0,0,0,0.08);">
                        <button style="width:100%; background:<?php echo esc_attr($brand); ?>; color:<?php echo esc_attr($text); ?>; border:none; padding:14px; border-radius:<?php echo esc_attr($radius); ?>px; font-weight:bold; cursor:pointer; font-family:<?php echo esc_attr($font); ?>;">
                            <?php echo esc_html($btn_txt); ?>
                        </button>
                        <p style="font-size:11px; color:#999; text-align:center; margin-top:8px;">Vista previa del botón</p>
                    </div>
                    <div style="background:#fff; border:1px solid #eee; border-radius:30px; padding:10px 16px; margin-top:16px; display:flex; align-items:center; gap:10px; box-shadow:0 4px 12px rgba(0,0,0,0.1);">
                        <span style="font-size:20px;">👤</span>
                        <div>
                            <div style="font-weight:bold; font-size:13px; color:<?php echo esc_attr($accent); ?>"><?php echo esc_html($f_title); ?></div>
                            <div style="font-size:10px; color:#888;"><?php echo esc_html($f_sub); ?></div>
                        </div>
                    </div>
                    <p style="font-size:11px; color:#999; text-align:center; margin-top:8px;">Vista previa del botón flotante</p>
                </div>
            </div>
        </div>
    </div>
    <?php
}

// ==========================================
// PÁGINA DE CRÉDITOS Y SUSCRIPCIÓN
// ==========================================
function mira_credits_page() {
    $tries_used   = (int) get_option( 'mira_stat_tries', 0 );
    $free_total   = (int) get_option( 'mira_free_tries_total', 7 );
    $paid_credits = (int) get_option( 'mira_paid_credits', 0 );
    $sub_status   = get_option( 'mira_subscription_status', 'none' );
    $sub_plan     = get_option( 'mira_subscription_plan', '' );
    $sub_end      = get_option( 'mira_subscription_end', '' );
    ?>
    <div class="wrap">
        <h1>💳 Créditos y Suscripción</h1>

        <!-- Estado actual -->
        <div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:24px; max-width:700px; margin-bottom:24px;">
            <h3 style="margin-top:0;">Estado actual</h3>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                <div style="background:#f9f9f9; border-radius:8px; padding:16px; text-align:center;">
                    <div style="font-size:32px; font-weight:700;"><?php echo max(0, $free_total - min($tries_used, $free_total)); ?></div>
                    <div style="color:#6b7280; font-size:13px;">Pruebas gratuitas restantes</div>
                </div>
                <div style="background:#f9f9f9; border-radius:8px; padding:16px; text-align:center;">
                    <div style="font-size:32px; font-weight:700;"><?php echo $paid_credits; ?></div>
                    <div style="color:#6b7280; font-size:13px;">Créditos de pago</div>
                </div>
            </div>
            <?php if ( $sub_status === 'active' || $sub_status === 'trialing' ) : ?>
            <div style="margin-top:16px; padding:12px; background:#f0fdf4; border-radius:8px; border:1px solid #86efac;">
                <strong><?php echo $sub_status === 'trialing' ? '⏳ Período de prueba activo' : '✅ Suscripción activa'; ?></strong> — Plan: <?php echo esc_html($sub_plan); ?>
                <?php if ( $sub_end ) : ?>
                <br><small style="color:#6b7280;">Próxima renovación: <?php echo esc_html($sub_end); ?></small>
                <?php endif; ?>
            </div>
            <?php else : ?>
            <div style="margin-top:16px; padding:12px; background:#fef2f2; border-radius:8px; border:1px solid #fca5a5;">
                ⚠️ Sin suscripción activa. Los créditos gratuitos son limitados.
            </div>
            <?php endif; ?>
        </div>

        <!-- Planes de suscripción -->
        <h2>Planes</h2>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:20px; max-width:700px; margin-bottom:24px;">
            <?php
            $plans = [
                [
                    'name'     => 'Básico',
                    'price_m'  => '20€/mes',
                    'price_a'  => '13€/mes',
                    'features' => ['75 fotos/mes', 'WhatsApp', 'Soporte básico'],
                    'link_m'   => get_option('mira_stripe_link_basic_monthly', '#'),
                    'link_a'   => get_option('mira_stripe_link_basic_annual', '#'),
                    'highlight'=> false,
                ],
                [
                    'name'     => 'Pro',
                    'price_m'  => '45€/mes',
                    'price_a'  => '25€/mes',
                    'features' => ['145 fotos/mes', 'WhatsApp + cupones', 'Dashboard completo', 'Tiendas ilimitadas'],
                    'link_m'   => get_option('mira_stripe_link_pro_monthly', '#'),
                    'link_a'   => get_option('mira_stripe_link_pro_annual', '#'),
                    'highlight'=> true,
                ],
            ];
            foreach ( $plans as $p ) :
                $border = $p['highlight'] ? '#8b7355' : '#e5e7eb';
            ?>
            <div style="background:#fff; border:2px solid <?php echo $border; ?>; border-radius:12px; padding:20px;">
                <?php if ( $p['highlight'] ) : ?>
                <div style="background:#8b7355; color:#fff; padding:3px 10px; border-radius:12px; font-size:11px; display:inline-block; margin-bottom:8px;">Más popular</div>
                <?php endif; ?>
                <h3 style="margin-top:0;"><?php echo esc_html($p['name']); ?></h3>
                <div style="font-size:22px; font-weight:700;"><?php echo esc_html($p['price_a']); ?> <small style="font-size:12px; color:#6b7280;">facturado anual</small></div>
                <div style="color:#6b7280; font-size:12px; margin-bottom:12px;"><?php echo esc_html($p['price_m']); ?> mes a mes</div>
                <ul style="padding:0; list-style:none; margin:0 0 16px 0;">
                    <?php foreach ( $p['features'] as $f ) : ?>
                    <li style="font-size:13px; padding:3px 0;">✓ <?php echo esc_html($f); ?></li>
                    <?php endforeach; ?>
                </ul>
                <a href="<?php echo esc_url($p['link_a']); ?>" target="_blank" class="button button-primary" style="width:100%; text-align:center; background:<?php echo $p['highlight'] ? '#1a1917' : ''; ?>;">
                    Suscribirse (Anual) →
                </a>
                <a href="<?php echo esc_url($p['link_m']); ?>" target="_blank" style="display:block; text-align:center; font-size:12px; color:#6b7280; margin-top:8px; text-decoration:none;">
                    O mensual
                </a>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Packs de créditos extra -->
        <h2>Packs de créditos extra</h2>
        <div style="display:grid; grid-template-columns:repeat(3,1fr); gap:16px; max-width:700px;">
            <?php
            $packs = [
                ['50 créditos', '15€', '#'],
                ['150 créditos', '28€', '#'],
                ['400 créditos', '60€', '#'],
            ];
            foreach ( $packs as $pk ) :
            ?>
            <div style="background:#fff; border:1px solid #e5e7eb; border-radius:10px; padding:16px; text-align:center;">
                <div style="font-size:20px; font-weight:700;"><?php echo $pk[0]; ?></div>
                <div style="font-size:24px; font-weight:700; margin:8px 0;"><?php echo $pk[1]; ?></div>
                <a href="<?php echo esc_url($pk[2]); ?>" target="_blank" class="button">Añadir →</a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php
}

// ==========================================
// WIZARD DE CONFIGURACIÓN
// ==========================================
function mira_wizard_page() {
    if ( isset( $_GET['skip'] ) ) {
        delete_option( 'mira_show_wizard' );
        wp_redirect( admin_url( 'admin.php?page=mira-dashboard' ) );
        exit;
    }

    if ( isset( $_POST['mira_wizard_save'] ) ) {
        check_admin_referer( 'mira_wizard_nonce', 'mira_wizard_nonce_field' );
        update_option( 'mira_webhook_reg', sanitize_url( $_POST['webhook_reg'] ?? '' ) );
        update_option( 'mira_webhook_gen', sanitize_url( $_POST['webhook_gen'] ?? '' ) );
        update_option( 'mira_stripe_pk', sanitize_text_field( $_POST['stripe_pk'] ?? '' ) );
        update_option( 'mira_color_brand', sanitize_hex_color( $_POST['color_brand'] ?? '#1a1917' ) );
        delete_option( 'mira_show_wizard' );
        echo '<div class="notice notice-success"><p>✅ Configuración completada. Mira está listo.</p></div>';
    }
    ?>
    <div class="wrap" style="max-width:680px;">
        <h1>🪄 Asistente de Configuración</h1>
        <p style="color:#6b7280;">Completa estos pasos para que Mira funcione correctamente en tu tienda.</p>

        <div style="display:flex; gap:8px; margin-bottom:24px; font-size:13px;">
            <?php
            $steps = ['Webhooks', 'Stripe', 'Diseño', 'Listo'];
            foreach ( $steps as $i => $s ) {
                $active = $i === 0 ? 'background:#1a1917; color:#fff;' : 'background:#e5e7eb; color:#6b7280;';
                echo '<div style="' . $active . ' padding:4px 12px; border-radius:20px;">' . ($i+1) . '. ' . esc_html($s) . '</div>';
            }
            ?>
        </div>

        <form method="post">
            <?php wp_nonce_field( 'mira_wizard_nonce', 'mira_wizard_nonce_field' ); ?>
            
            <div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:24px; margin-bottom:16px;">
                <h3 style="margin-top:0;">Paso 1: Conecta Make</h3>
                <p style="color:#6b7280; font-size:13px;">Crea dos escenarios en Make y pega aquí las URLs de los webhooks de entrada.</p>
                <label style="display:block; margin-bottom:8px; font-weight:600;">Webhook de Registro</label>
                <input type="url" name="webhook_reg" value="<?php echo esc_attr(get_option('mira_webhook_reg')); ?>" class="large-text" placeholder="https://hook.eu1.make.com/abc123...">
                <label style="display:block; margin:12px 0 8px; font-weight:600;">Webhook de Generación</label>
                <input type="url" name="webhook_gen" value="<?php echo esc_attr(get_option('mira_webhook_gen')); ?>" class="large-text" placeholder="https://hook.eu1.make.com/xyz456...">
            </div>

            <div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:24px; margin-bottom:16px;">
                <h3 style="margin-top:0;">Paso 2: Stripe (Opcional)</h3>
                <p style="color:#6b7280; font-size:13px;">Necesario para recibir pagos automáticamente y gestionar suscripciones.</p>
                <label style="display:block; margin-bottom:8px; font-weight:600;">Clave Pública de Stripe</label>
                <input type="text" name="stripe_pk" value="<?php echo esc_attr(get_option('mira_stripe_pk')); ?>" class="large-text" placeholder="pk_live_...">
                <p style="font-size:12px; color:#6b7280; margin-top:8px;">
                    Configura el webhook en: <code><?php echo esc_url( rest_url( 'mira/v1/stripe-webhook' ) ); ?></code>
                </p>
            </div>

            <div style="background:#fff; border:1px solid #e5e7eb; border-radius:12px; padding:24px; margin-bottom:16px;">
                <h3 style="margin-top:0;">Paso 3: Color de marca</h3>
                <label style="display:block; margin-bottom:8px; font-weight:600;">Color principal</label>
                <input type="color" name="color_brand" value="<?php echo esc_attr(get_option('mira_color_brand', '#1a1917')); ?>">
                <p style="font-size:12px; color:#6b7280; margin-top:8px;">Puedes personalizar más en Mira IA → Diseño.</p>
            </div>

            <input type="submit" name="mira_wizard_save" class="button button-primary button-large" value="✅ Finalizar Configuración">
            <a href="<?php echo esc_url( admin_url('admin.php?page=mira-dashboard') ); ?>" style="margin-left:12px; color:#6b7280;">Omitir</a>
        </form>
    </div>
    <?php
}

// ==========================================
// 0. CUSTOM POST TYPE (OUTFITS)
// ==========================================
add_action( 'init', 'mira_register_outfit_cpt' );
function mira_register_outfit_cpt() {
    register_post_type( 'hunix_outfit', [
        'labels'       => [ 'name' => 'Outfits Virtuales', 'singular_name' => 'Outfit', 'add_new_item' => 'Añadir Outfit' ],
        'public'       => true,
        'show_ui'      => true,
        'menu_position'=> 5,
        'menu_icon'    => 'dashicons-format-gallery',
        'supports'     => [ 'title', 'thumbnail' ],
        'rewrite'      => [ 'slug' => 'outfit-virtual' ],
        'show_in_rest' => true,
    ]);
}

// ==========================================
// 1. META BOX — IMÁGENES POR PRODUCTO/VARIACIÓN + OPTIMIZACIÓN IA
// ==========================================
add_action( 'add_meta_boxes', 'mira_add_meta_box' );
function mira_add_meta_box() {
    foreach ( [ 'product', 'hunix_outfit' ] as $screen ) {
        add_meta_box( 'mira_ai_box', '📸 Mira IA — Imagen & Configuración', 'mira_render_meta_box', $screen, 'normal', 'high' );
    }
}

function mira_render_meta_box( $post ) {
    wp_nonce_field( 'mira_save_meta', 'mira_meta_nonce' );
    $is_product = $post->post_type === 'product';
    $product    = $is_product && function_exists( 'wc_get_product' ) ? wc_get_product( $post->ID ) : null;

    // Detectar categoría del producto para recomendar tipo de modelo
    $category_type = get_post_meta( $post->ID, '_mira_category_type', true ) ?: 'clothing';
    $dalle_key     = get_option( 'mira_dalle_key' );

    echo '<div style="padding:10px;">';
    
    // Selector de tipo de categoría
    echo '<p><label style="font-weight:bold">🏷️ Tipo de producto (para IA):</label><br>';
    echo '<select name="_mira_category_type" style="margin-top:4px; padding:6px;">';
    $types = [ 'clothing' => '👗 Ropa (try-on completo)', 'glasses' => '🕶️ Gafas (Face Landmarks)', 'jewelry' => '💍 Joyas / Accesorios (Face/Wrist)', 'bag' => '👜 Bolsos (Pose Estimation)', 'other' => '📦 Otro' ];
    foreach ( $types as $val => $label ) {
        echo '<option value="' . esc_attr($val) . '"' . selected($category_type, $val, false) . '>' . esc_html($label) . '</option>';
    }
    echo '</select>';
    echo '<span style="margin-left:8px; font-size:12px; color:#6b7280;">Esto determina el modelo de IA a usar en Make.</span></p>';

    // Botón optimización IA (si hay clave)
    if ( $dalle_key && $is_product && has_post_thumbnail($post->ID) ) {
        $thumb_url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) );
        echo '<div style="background:#f0f9ff; border:1px solid #bae6fd; border-radius:8px; padding:12px; margin-bottom:12px;">';
        echo '<strong>🤖 Optimización con IA</strong><br>';
        echo '<span style="font-size:12px; color:#6b7280;">Si la foto del producto está incompleta, la IA puede generar una versión en maniquí neutro.</span><br>';
        echo '<button type="button" id="mira-optimize-btn" onclick="miraOptimizeImage(\'' . esc_url($thumb_url) . '\', ' . $post->ID . ')" style="margin-top:8px; background:#0ea5e9; color:#fff; border:none; padding:6px 14px; border-radius:6px; cursor:pointer;">✨ Optimizar para IA</button>';
        echo '<span id="mira-optimize-status" style="margin-left:8px; font-size:12px; color:#6b7280;"></span>';
        echo '</div>';
    }

    // Imagen IA
    echo '<p><label><strong>🔗 URL Imagen IA (flat lay o maniquí):</strong></label><br>';
    echo '<em style="font-size:12px; color:#6b7280;">Deja vacío para usar la imagen destacada.</em></p>';

    if ( !$is_product || ($product && $product->is_type('simple')) || $post->post_type === 'hunix_outfit' ) {
        $val = get_post_meta( $post->ID, '_hunix_hidden_ai_img', true );
        echo '<input type="text" name="_hunix_hidden_ai_img" value="' . esc_attr($val) . '" style="width:100%;" placeholder="https://...">'; 
    } elseif ( $product && $product->is_type('variable') ) {
        $variations = $product->get_children();
        if ( empty($variations) ) {
            echo '<div style="background:#fff3cd; padding:10px; border-radius:6px;">⚠️ Crea variaciones primero.</div>';
        } else {
            echo '<table class="widefat" style="margin-top:8px;"><thead><tr><th>Variación</th><th>Imagen IA</th><th>Tipo IA</th></tr></thead><tbody>';
            foreach ( $variations as $var_id ) {
                $variation = wc_get_product( $var_id );
                if ( !$variation ) continue;
                $attrs    = wc_get_formatted_variation( $variation, true ) ?: "ID #$var_id";
                $saved    = get_post_meta( $var_id, '_hunix_hidden_ai_img', true );
                $var_type = get_post_meta( $var_id, '_mira_category_type', true ) ?: $category_type;
                echo '<tr>';
                echo '<td><strong>' . esc_html($attrs) . '</strong></td>';
                echo '<td><input type="text" name="mira_var_img[' . $var_id . ']" value="' . esc_attr($saved) . '" style="width:100%;" placeholder="https://..."></td>';
                echo '<td><select name="mira_var_type[' . $var_id . ']">';
                foreach ( $types as $val => $label ) {
                    echo '<option value="' . esc_attr($val) . '"' . selected($var_type, $val, false) . '>' . esc_html($label) . '</option>';
                }
                echo '</select></td>';
                echo '</tr>';
            }
            echo '</tbody></table>';
        }
    }
    echo '</div>';

    // JS optimización IA
    if ( $dalle_key ) : ?>
    <script>
    function miraOptimizeImage(imageUrl, postId) {
        var status = document.getElementById('mira-optimize-status');
        var btn    = document.getElementById('mira-optimize-btn');
        btn.disabled = true;
        status.textContent = '⏳ Procesando con IA...';
        fetch('<?php echo esc_url( rest_url('mira/v1/optimize-image') ); ?>', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': '<?php echo wp_create_nonce('wp_rest'); ?>' },
            body: JSON.stringify({ image_url: imageUrl, post_id: postId })
        }).then(r => r.json()).then(data => {
            if (data.success && data.url) {
                document.querySelector('input[name="_hunix_hidden_ai_img"]').value = data.url;
                status.textContent = '✅ Imagen optimizada y guardada.';
                status.style.color = '#22c55e';
            } else {
                status.textContent = '❌ Error: ' + (data.message || 'desconocido');
                status.style.color = '#ef4444';
            }
            btn.disabled = false;
        }).catch(() => {
            status.textContent = '❌ Error de conexión.';
            status.style.color = '#ef4444';
            btn.disabled = false;
        });
    }
    </script>
    <?php endif;
}

add_action( 'save_post', 'mira_save_meta' );
function mira_save_meta( $post_id ) {
    if ( ! isset( $_POST['mira_meta_nonce'] ) || ! wp_verify_nonce( $_POST['mira_meta_nonce'], 'mira_save_meta' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;

    if ( isset( $_POST['_hunix_hidden_ai_img'] ) ) {
        update_post_meta( $post_id, '_hunix_hidden_ai_img', sanitize_text_field( $_POST['_hunix_hidden_ai_img'] ) );
    }
    if ( isset( $_POST['_mira_category_type'] ) ) {
        update_post_meta( $post_id, '_mira_category_type', sanitize_text_field( $_POST['_mira_category_type'] ) );
    }
    if ( isset( $_POST['mira_var_img'] ) && is_array( $_POST['mira_var_img'] ) ) {
        foreach ( $_POST['mira_var_img'] as $var_id => $url ) {
            update_post_meta( (int)$var_id, '_hunix_hidden_ai_img', sanitize_text_field( $url ) );
        }
    }
    if ( isset( $_POST['mira_var_type'] ) && is_array( $_POST['mira_var_type'] ) ) {
        foreach ( $_POST['mira_var_type'] as $var_id => $type ) {
            update_post_meta( (int)$var_id, '_mira_category_type', sanitize_text_field( $type ) );
        }
    }
    if ( function_exists('wc_delete_product_transients') ) wc_delete_product_transients( $post_id );
}

// ==========================================
// 2. CSS DINÁMICO (INYECCIÓN DE MARCA)
// ==========================================
add_action( 'wp_head', 'mira_inject_dynamic_css' );
function mira_inject_dynamic_css() {
    $brand  = get_option( 'mira_color_brand', '#1a1917' );
    $text   = get_option( 'mira_color_text', '#FFFFFF' );
    $accent = get_option( 'mira_color_accent', '#8b7355' );
    $radius = (int) get_option( 'mira_btn_radius', 8 );
    $font   = get_option( 'mira_font_family', 'inherit' );

    // Convertir hex a rgb para sombras
    $rgb = mira_hex_to_rgb( $brand );
    $rgb_str = implode(',', $rgb);

    echo '<style id="mira-dynamic-css">';
    echo ':root {';
    echo '--mira-brand: ' . esc_attr($brand) . ';';
    echo '--mira-text: ' . esc_attr($text) . ';';
    echo '--mira-accent: ' . esc_attr($accent) . ';';
    echo '--mira-radius: ' . esc_attr($radius) . 'px;';
    echo '--mira-font: ' . esc_attr($font) . ';';
    echo '--mira-brand-rgb: ' . esc_attr($rgb_str) . ';';
    echo '}';
    echo '.hx-animated-btn { animation: hx-pulse 2s infinite; transition: all 0.3s; }';
    echo '.hx-animated-btn:hover { animation: none; transform: scale(1.02); }';
    echo '.hx-animated-btn[disabled] { animation: none; }';
    echo '@keyframes hx-pulse { 0%,100% { transform: scale(1); box-shadow: 0 0 0 0 rgba(' . esc_attr($rgb_str) . ',0.3); } 50% { transform: scale(1.02); box-shadow: 0 0 0 8px rgba(' . esc_attr($rgb_str) . ',0); } }';
    echo '@keyframes hx-float-pulse { 0%,100% { transform: scale(1); box-shadow: 0 5px 20px rgba(0,0,0,0.15); } 50% { transform: scale(1.04); box-shadow: 0 8px 25px rgba(0,0,0,0.2); } }';
    echo '#hunix-float { animation: hx-float-pulse 3s infinite ease-in-out; }';
    echo '#hunix-float:hover { animation: none; transform: scale(1.05); }';
    echo '.hx-tab.active { background:#fff; color:#000 !important; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }';
    echo '</style>';
}

function mira_hex_to_rgb( $hex ) {
    $hex = ltrim( $hex, '#' );
    if ( strlen($hex) === 3 ) {
        $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    }
    return [ hexdec(substr($hex,0,2)), hexdec(substr($hex,2,2)), hexdec(substr($hex,4,2)) ];
}

// ==========================================
// 3. FRONTEND UI
// ==========================================
function mira_is_tryon_page() {
    if ( ! is_singular() ) return false;
    $post = get_post();
    return $post && has_shortcode( $post->post_content, 'hunix_tryon_page' );
}

add_filter( 'body_class', function($classes) {
    if ( mira_is_tryon_page() ) $classes[] = 'hunix-tryon-page';
    return $classes;
});

add_action( 'wp_footer', 'mira_render_ui' );
function mira_render_ui() {
    $bg        = get_option( 'mira_color_brand', '#1a1917' );
    $accent    = get_option( 'mira_color_accent', '#8b7355' );
    $pos       = get_option( 'mira_float_pos', 'right' );
    $pos_css   = $pos === 'left' ? 'left:20px;' : 'right:20px;';
    $instr_html= nl2br( esc_html( get_option( 'mira_instr_text', "1. Sube tu foto.\n2. Guarda el perfil.\n3. Pruébate la ropa." ) ) );
    $policy    = esc_html( get_option( 'mira_policy_text', 'Acepto el uso de mi imagen.' ) );
    $f_title   = esc_html( get_option( 'mira_float_title', 'Mi Perfil IA' ) );
    $f_sub     = esc_html( get_option( 'mira_float_sub', 'Gestionar foto' ) );
    $hide_float= mira_is_tryon_page();

    // Control de créditos
    $tries_used   = (int) get_option( 'mira_stat_tries', 0 );
    $free_total   = (int) get_option( 'mira_free_tries_total', 7 );
    $paid_credits = (int) get_option( 'mira_paid_credits', 0 );
    $sub_status   = get_option( 'mira_subscription_status', 'none' );
    $has_credits  = $sub_status === 'active' || $sub_status === 'trialing' || $paid_credits > 0 || $tries_used < $free_total;
    $stripe_link  = get_option( 'mira_stripe_link_basic_annual', 'https://buy.stripe.com/4gM3cw8TJ856h22baN1ck00' );
    ?>
    <!-- Toast -->
    <div id="hx-toast" style="display:none; position:fixed; top:30px; left:50%; transform:translateX(-50%); background:#1a1917; color:#fff; padding:12px 24px; border-radius:50px; z-index:999999999; font-weight:bold; box-shadow:0 10px 40px rgba(0,0,0,0.3); align-items:center; gap:10px; text-align:center; max-width:90%;">
        <span id="hx-t-icon"></span> <span id="hx-t-msg"></span>
    </div>

    <?php if ( ! $hide_float ) : ?>
    <!-- Botón flotante -->
    <div id="hunix-float" style="position:fixed; bottom:20px; <?php echo $pos_css; ?> background:#fff; padding:10px 20px; border-radius:50px; cursor:pointer; z-index:9999; border:1px solid #eee; display:flex; align-items:center; gap:10px; box-shadow:0 5px 20px rgba(0,0,0,0.12);">
        <span style="font-size:22px;">👤</span>
        <div style="line-height:1.2;">
            <div style="font-weight:bold; font-size:13px; color:<?php echo esc_attr($accent); ?>"><?php echo $f_title; ?></div>
            <div style="font-size:10px; color:#888;"><?php echo $f_sub; ?></div>
        </div>
        <div id="hx-dot" style="display:none; width:10px; height:10px; background:#22c55e; border-radius:50%; position:absolute; top:0; right:0;"></div>
    </div>
    <?php endif; ?>

    <!-- Modal principal -->
    <div id="hunix-modal-wrap" style="display:none; position:fixed !important; inset:0 !important; width:100% !important; height:100% !important; background:rgba(0,0,0,0.7) !important; z-index:999999 !important; justify-content:center !important; align-items:center !important;">
        <div style="background:#fff; width:90%; max-width:400px; padding:30px; border-radius:24px; position:relative; max-height:90vh; overflow-y:auto; box-shadow:0 20px 60px rgba(0,0,0,0.25);">
            <button id="hx-close" style="position:absolute; top:15px; right:15px; background:none; border:none; font-size:24px; cursor:pointer; color:#888;">&times;</button>

            <!-- STEP 1: Formulario -->
            <div id="hx-step-1">
                <h3 style="text-align:center; margin-top:0; margin-bottom:4px; font-size:18px;">Tu Perfil de Modelo</h3>
                <p style="text-align:center; font-size:12px; color:#888; margin-top:0 0 16px;">Una foto + tu WhatsApp. Sin apps, sin registro.</p>

                <?php if ( ! $has_credits ) : ?>
                <!-- MURO DE PAGO -->
                <div style="text-align:center; padding:20px; background:#fef9ec; border-radius:12px; margin-bottom:16px;">
                    <div style="font-size:40px; margin-bottom:8px;">⭐</div>
                    <h4 style="margin:0 0 8px;">Has agotado tus pruebas gratuitas</h4>
                    <p style="font-size:13px; color:#6b7280; margin-bottom:16px;">Suscríbete para seguir usando el probador virtual.</p>
                    <a href="<?php echo esc_url($stripe_link); ?>" target="_blank" style="display:inline-block; background:<?php echo esc_attr($bg); ?>; color:#fff; padding:12px 24px; border-radius:8px; font-weight:bold; text-decoration:none;">
                        Suscribirse desde 13€/mes →
                    </a>
                    <p style="font-size:11px; color:#aaa; margin-top:8px;">3 días gratis. Cancela cuando quieras.</p>
                </div>
                <?php else : ?>

                <details style="background:#f9f9f9; padding:10px; border-radius:8px; margin-bottom:16px; border:1px solid #eee;">
                    <summary style="font-weight:bold; cursor:pointer; color:<?php echo esc_attr($accent); ?>;">❓ ¿Cómo funciona?</summary>
                    <div style="margin-top:10px; font-size:13px; line-height:1.5; color:#555;">
                        <?php echo $instr_html; ?>
                    </div>
                </details>

                <label style="font-size:11px; font-weight:bold; color:#aaa; letter-spacing:.05em;">TUS DATOS</label>
                <input type="text" id="hx-name" placeholder="Tu nombre" style="width:100%; padding:10px; border:1px solid #ddd; border-radius:8px; margin:6px 0 10px; box-sizing:border-box;">
                <div style="display:flex; gap:5px; margin-bottom:14px;">
                    <select id="hx-pre" style="width:90px; padding:10px; border:1px solid #ddd; border-radius:8px;">
                        <option value="+34">ES +34</option>
                        <option value="+1">US +1</option>
                        <option value="+52">MX +52</option>
                        <option value="+54">AR +54</option>
                        <option value="+44">UK +44</option>
                        <option value="+33">FR +33</option>
                    </select>
                    <input type="tel" id="hx-tel" placeholder="Tu WhatsApp" style="flex:1; padding:10px; border:1px solid #ddd; border-radius:8px;">
                </div>

                <label style="font-size:11px; font-weight:bold; color:#aaa; letter-spacing:.05em;">TU FOTO</label>
                <div style="background:#f5f5f5; padding:5px; border-radius:8px; display:flex; gap:5px; margin:6px 0 10px;">
                    <div class="hx-tab active" id="tab-up" style="flex:1; text-align:center; padding:8px; cursor:pointer; background:#fff; border-radius:5px; font-weight:bold; font-size:13px;">📁 Subir</div>
                    <div class="hx-tab" id="tab-cam" style="flex:1; text-align:center; padding:8px; cursor:pointer; font-size:13px;">📷 Cámara</div>
                </div>

                <div id="box-up" style="border:2px dashed #ddd; height:140px; border-radius:10px; display:flex; align-items:center; justify-content:center; cursor:pointer; position:relative; overflow:hidden;" onclick="document.getElementById('hx-file').click()">
                    <div style="text-align:center; color:#aaa; pointer-events:none;">
                        <div style="font-size:28px;">⬆️</div>
                        <div style="font-size:12px; margin-top:4px;">Pulsa para subir tu foto</div>
                    </div>
                    <input type="file" id="hx-file" hidden accept="image/*">
                    <div id="preview-up" style="position:absolute; inset:0; background-size:cover; background-position:center;"></div>
                </div>

                <div id="box-cam" style="display:none; height:200px; position:relative; background:#000; border-radius:10px; overflow:hidden;">
                    <video id="hx-vid" autoplay playsinline style="width:100%; height:100%; object-fit:cover;"></video>
                    <canvas id="hx-can" style="display:none;"></canvas>
                    <button id="hx-snap" style="position:absolute; bottom:10px; left:50%; transform:translateX(-50%); background:#fff; padding:6px 16px; border-radius:20px; border:none; font-weight:bold; cursor:pointer;">📸 FOTO</button>
                    <div id="preview-cam" style="position:absolute; inset:0; background-size:cover; background-position:center; display:none;"></div>
                    <button id="hx-retake" style="display:none; position:absolute; top:10px; left:10px; background:rgba(0,0,0,0.5); color:#fff; padding:4px 10px; border-radius:5px; border:none; font-size:11px; cursor:pointer;">Repetir</button>
                </div>

                <div style="margin-top:12px; font-size:12px; display:flex; gap:8px; align-items:start;">
                    <input type="checkbox" id="hx-policy" style="margin-top:2px;">
                    <label for="hx-policy" style="color:#666; line-height:1.3;"><?php echo $policy; ?></label>
                </div>
                <button id="hx-save" style="width:100%; background:<?php echo esc_attr($bg); ?>; color:#fff; padding:14px; margin-top:14px; border:none; border-radius:var(--mira-radius, 8px); font-weight:bold; cursor:pointer; font-size:15px; font-family:var(--mira-font, inherit);">GUARDAR PERFIL</button>
                
                <?php endif; ?>
            </div>

            <!-- STEP 2: Éxito -->
            <div id="hx-step-2" style="display:none; text-align:center;">
                <div style="font-size:50px; margin-bottom:12px;">🎉</div>
                <h3 style="margin-top:0;">¡Perfil guardado!</h3>
                <p style="color:#666; font-size:13px; margin-bottom:20px;">Ya puedes probar cualquier look. El resultado llega a tu WhatsApp.</p>
                <button id="hx-finish" style="width:100%; background:<?php echo esc_attr($bg); ?>; color:#fff; padding:14px; border:none; border-radius:var(--mira-radius, 8px); font-weight:bold; cursor:pointer;">Cerrar y Probar →</button>
            </div>

            <!-- STEP READY: Perfil activo -->
            <div id="hx-step-ready" style="display:none; text-align:center;">
                <div style="font-size:50px; margin-bottom:12px;">✅</div>
                <h3 style="margin-top:0;">¡Perfil activo!</h3>
                <p style="color:#555; font-size:14px; margin-bottom:20px; line-height:1.5;">Tienes foto guardada. Usa el botón "Probar" en los productos.</p>
                <button id="hx-close-ready" style="width:100%; background:<?php echo esc_attr($bg); ?>; color:#fff; padding:14px; border:none; border-radius:var(--mira-radius, 8px); font-weight:bold; cursor:pointer;">Entendido, cerrar</button>
                <div style="margin-top:12px;"><a href="#" id="hx-edit-profile" style="font-size:12px; color:#999; text-decoration:underline;">Cambiar mi foto</a></div>
            </div>
        </div>
    </div>
    <?php
}

// ==========================================
// 4. BOTÓN EN PRODUCTO (CON DETECCIÓN DE CATEGORÍA)
// ==========================================
add_action( 'woocommerce_after_add_to_cart_button', 'mira_render_button' );
function mira_render_button() {
    global $product;
    if ( ! $product ) return;

    // Control de créditos
    $tries_used = (int) get_option( 'mira_stat_tries', 0 );
    $free_total = (int) get_option( 'mira_free_tries_total', 7 );
    $paid_credits = (int) get_option( 'mira_paid_credits', 0 );
    $sub_status = get_option( 'mira_subscription_status', 'none' );
    $has_credits = $sub_status === 'active' || $sub_status === 'trialing' || $paid_credits > 0 || $tries_used < $free_total;

    $bg      = get_option( 'mira_color_brand', '#1a1917' );
    $col     = get_option( 'mira_color_text', '#FFFFFF' );
    $txt     = get_option( 'mira_btn_txt', '✨ PROBAR ESTE LOOK' );
    $radius  = (int) get_option( 'mira_btn_radius', 8 );
    $font    = get_option( 'mira_font_family', 'inherit' );

    // Detectar tipo de categoría del producto
    $cat_type = get_post_meta( $product->get_id(), '_mira_category_type', true ) ?: 'clothing';

    // Detectar ícono por tipo
    $icon_map = [ 'clothing' => '👗', 'glasses' => '🕶️', 'jewelry' => '💍', 'bag' => '👜', 'other' => '🪄' ];
    $icon     = $icon_map[$cat_type] ?? '✨';

    $main_image_url = wp_get_attachment_url( $product->get_image_id() );
    $custom_main    = get_post_meta( $product->get_id(), '_hunix_hidden_ai_img', true );
    if ( ! empty( $custom_main ) ) $main_image_url = $custom_main;

    $colors_found = [];
    $is_variable  = false;

    if ( $product->is_type( 'variable' ) ) {
        $is_variable = true;
        foreach ( $product->get_available_variations() as $var ) {
            $color_name = '';
            foreach ( $var['attributes'] as $slug => $value ) {
                if ( strpos($slug, 'color') !== false || strpos($slug, 'colour') !== false ) {
                    $color_name = ucfirst($value); break;
                }
            }
            if ( empty($color_name) ) {
                foreach ( $var['attributes'] as $slug => $value ) {
                    if ( $slug !== 'attribute_pa_size' && $slug !== 'attribute_pa_talla' && strpos($slug,'size') === false ) {
                        $color_name = ucfirst($value); break;
                    }
                }
            }
            $var_id   = $var['variation_id'];
            $var_type = get_post_meta( $var_id, '_mira_category_type', true ) ?: $cat_type;
            $hidden   = get_post_meta( $var_id, '_hunix_hidden_ai_img', true );
            $img      = ! empty($hidden) ? $hidden : $var['image']['src'];
            if ( $color_name && ! empty($img) && ! isset($colors_found[$color_name]) ) {
                $colors_found[$color_name] = [ 'img' => $img, 'type' => $var_type ];
            }
        }
    }

    echo '<div id="hunix-container" style="margin-top:20px; padding:16px; border:1px solid #eee; border-radius:12px; background:#fcfcfc; display:none;">';
    echo '<input type="hidden" id="hx-default-img" value="' . esc_url($main_image_url) . '">';
    echo '<input type="hidden" id="hx-cat-type" value="' . esc_attr($cat_type) . '">';

    $count = count($colors_found);

    if ( $is_variable && $count > 1 ) {
        echo '<label style="display:block; font-size:12px; font-weight:bold; margin-bottom:5px; color:#666;">🎨 Elige qué probar:</label>';
        echo '<select id="hx-ai-selector" style="width:100%; margin-bottom:10px; padding:8px; border-radius:6px; border:1px solid #ccc;">';
        echo '<option value="default" data-img="' . esc_url($main_image_url) . '" data-type="' . esc_attr($cat_type) . '">-- Selecciona --</option>';
        foreach ( $colors_found as $name => $info ) {
            echo '<option value="' . esc_attr($name) . '" data-img="' . esc_url($info['img']) . '" data-type="' . esc_attr($info['type']) . '">' . esc_html($name) . '</option>';
        }
        echo '<option value="all" style="font-weight:bold; color:#22c55e;">✨ PROBAR TODOS</option>';
        echo '</select>';
    } elseif ( $is_variable && $count === 1 ) {
        reset( $colors_found );
        $s_name = key($colors_found);
        $s_info = $colors_found[$s_name];
        echo '<input type="hidden" id="hx-single-img" value="' . esc_url($s_info['img']) . '" data-name="' . esc_attr($s_name) . '" data-type="' . esc_attr($s_info['type']) . '">';
        $txt = $icon . ' PROBAR EN ' . strtoupper($s_name);
    }

    $disabled = $count > 1 ? 'disabled' : '';
    $btn_style = 'cursor:pointer;';
    
    if ( ! $has_credits ) {
        $stripe_link = get_option( 'mira_stripe_link_basic_annual', '#' );
        echo '<div style="text-align:center; background:#fef9ec; border-radius:8px; padding:12px; font-size:13px;">';
        echo '<strong>Has agotado tus pruebas gratuitas.</strong><br>';
        echo '<a href="' . esc_url($stripe_link) . '" target="_blank" style="color:' . esc_attr($bg) . '; font-weight:bold;">Suscríbete para seguir →</a>';
        echo '</div>';
    } else {
        echo '<button type="button" id="hunix-btn" class="button alt hx-animated-btn" ' . $disabled . ' ';
        echo 'style="width:100%; background:' . ( $count > 1 ? '#999' : esc_attr($bg) ) . '; color:' . esc_attr($col) . '; border-radius:' . $radius . 'px; padding:14px; border:none; font-weight:bold; display:flex; justify-content:center; align-items:center; gap:8px; font-family:' . esc_attr($font) . '; font-size:15px; ' . $btn_style . '">';
        echo '<span>' . esc_html($icon) . '</span> <span id="hx-btn-text">' . esc_html($txt) . '</span>';
        echo '</button>';
    }

    echo '<div id="hx-loader-wrap" style="width:100%; height:3px; background:#eee; margin-top:8px; border-radius:4px; display:none;"><div id="hx-loader" style="width:0%; height:100%; background:' . esc_attr($bg) . '; transition:width 0.5s; border-radius:4px;"></div></div>';
    echo '<p id="hx-msg" style="text-align:center; font-size:11px; margin-top:6px; color:#666; display:none;"></p>';
    echo '</div>';
}

// ==========================================
// 5. ENQUEUE ASSETS
// ==========================================
add_action( 'wp_enqueue_scripts', function() {
    wp_enqueue_script( 'mira-js', MIRA_PLUGIN_URL . '/assets/app.js', ['jquery'], MIRA_VERSION, true );
    wp_enqueue_style( 'mira-css', MIRA_PLUGIN_URL . '/assets/app.css', [], MIRA_VERSION );

    $prod_link = is_product() ? get_permalink() : '';

    // Categorías de WooCommerce del producto actual
    $prod_cats = [];
    if ( is_product() ) {
        $cats = get_the_terms( get_the_ID(), 'product_cat' );
        if ( $cats && ! is_wp_error($cats) ) {
            $prod_cats = wp_list_pluck( $cats, 'name' );
        }
    }

    wp_localize_script( 'mira-js', 'hx_vars', [
        'wh_reg'      => get_option( 'mira_webhook_reg' ),
        'wh_gen'      => get_option( 'mira_webhook_gen' ),
        'btn_def'     => get_option( 'mira_btn_txt', '✨ PROBAR ESTE LOOK' ),
        'brand_color' => get_option( 'mira_color_brand', '#1a1917' ),
        'api_up'      => get_rest_url( null, 'mira/v1/up' ),
        'api_st'      => get_rest_url( null, 'mira/v1/stats' ),
        'api_credits' => get_rest_url( null, 'mira/v1/check-credits' ),
        'nonce'       => wp_create_nonce( 'wp_rest' ),
        'prod_link'   => $prod_link,
        'prod_cats'   => $prod_cats,
        'stripe_link' => get_option( 'mira_stripe_link_basic_annual', '#' ),
    ]);
});

// ==========================================
// 6. REST API ENDPOINTS
// ==========================================
add_action( 'rest_api_init', function() {
    // Subida de foto
    register_rest_route( 'mira/v1', '/up', [
        'methods'             => 'POST',
        'callback'            => 'mira_upload_safe',
        'permission_callback' => '__return_true',
    ]);

    // Estadísticas
    register_rest_route( 'mira/v1', '/stats', [
        'methods'             => 'POST',
        'callback'            => 'mira_stats',
        'permission_callback' => '__return_true',
    ]);

    // Check créditos
    register_rest_route( 'mira/v1', '/check-credits', [
        'methods'             => 'GET',
        'callback'            => 'mira_check_credits',
        'permission_callback' => '__return_true',
    ]);

    // Webhook de Stripe
    register_rest_route( 'mira/v1', '/stripe-webhook', [
        'methods'             => 'POST',
        'callback'            => 'mira_stripe_webhook',
        'permission_callback' => '__return_true',
    ]);

    // Optimización de imagen con IA
    register_rest_route( 'mira/v1', '/optimize-image', [
        'methods'             => 'POST',
        'callback'            => 'mira_optimize_image',
        'permission_callback' => function() { return current_user_can('edit_posts'); },
    ]);
});

function mira_upload_safe( $req ) {
    $files = $req->get_file_params();
    if ( empty($files['file']) ) return new WP_Error( 'no_file', 'Falta archivo', ['status' => 400] );
    if ( ! function_exists('wp_handle_upload') ) require_once( ABSPATH . 'wp-admin/includes/file.php' );
    $moved = wp_handle_upload( $files['file'], ['test_form' => false] );
    if ( $moved && ! isset($moved['error']) ) return ['success' => true, 'url' => $moved['url']];
    return new WP_Error( 'upload_error', $moved['error'], ['status' => 500] );
}

function mira_stats( $req ) {
    $type = $req->get_param('type');
    if ( $type === 'user' ) {
        update_option( 'mira_stat_users', (int)get_option('mira_stat_users', 0) + 1 );
    }
    if ( $type === 'try' ) {
        $tries = (int)get_option( 'mira_stat_tries', 0 ) + 1;
        update_option( 'mira_stat_tries', $tries );

        // ── Llamar a Make: resta 1 crédito en Google Sheets y devuelve saldo ──
        $license      = get_option('mira_license_key', '');
        $make_sub_url = get_option('mira_make_credits_sub', '');

        if ( ! empty($license) && ! empty($make_sub_url) ) {
            $resp = wp_remote_post( $make_sub_url, [
                'timeout' => 10,
                'headers' => ['Content-Type' => 'application/json'],
                'body'    => wp_json_encode([
                    'license' => $license,
                    'action'  => 'subtract',
                    'amount'  => 1,
                ]),
            ]);
            if ( ! is_wp_error($resp) ) {
                $body = json_decode( wp_remote_retrieve_body($resp), true );
                if ( isset($body['credits_remaining']) ) {
                    return ['success' => true, 'credits_remaining' => (int)$body['credits_remaining']];
                }
            }
        }

        // Fallback local si Make no responde
        $sub_status   = get_option('mira_subscription_status', 'none');
        $free_total   = (int)get_option('mira_free_tries_total', 5);
        $paid_credits = (int)get_option('mira_paid_credits', 0);
        if ( $sub_status !== 'active' && $sub_status !== 'trialing' ) {
            if ( $tries > $free_total && $paid_credits > 0 ) {
                update_option('mira_paid_credits', $paid_credits - 1);
            }
        }
    }
    return ['success' => true];
}

function mira_check_credits() {
    $license = get_option('mira_license_key', '');

    // Lectura directa de Google Sheets (0 operaciones Make)
    if ( ! empty($license) ) {
        $data = mira_gsheet_read($license);
        if ( $data !== false ) {
            update_option('mira_free_tries_total',   $data['credits_total']);
            update_option('mira_paid_credits',        $data['credits_extra']);
            update_option('mira_subscription_status', $data['subscription']);
            return $data;
        }
    }

    // Fallback: BD local de WordPress
    $tries_used   = (int) get_option('mira_stat_tries', 0);
    $free_total   = (int) get_option('mira_free_tries_total', 5);
    $paid_credits = (int) get_option('mira_paid_credits', 0);
    $sub_status   = get_option('mira_subscription_status', 'trialing');
    $has_credits  = $sub_status === 'active' || $sub_status === 'trialing'
                    || $paid_credits > 0 || $tries_used < $free_total;
    return [
        'has_credits'       => $has_credits,
        'credits_remaining' => max(0, $free_total - $tries_used) + $paid_credits,
        'credits_total'     => $free_total,
        'credits_used'      => $tries_used,
        'credits_extra'     => $paid_credits,
        'subscription'      => $sub_status,
        'source'            => 'local_fallback',
    ];
}

function mira_stripe_webhook( WP_REST_Request $req ) {
    $payload = $req->get_body();
    $sig     = $req->get_header('stripe-signature');
    $secret  = get_option( 'mira_stripe_webhook_secret' );

    // Verificar firma de Stripe (manual, sin librería)
    if ( $secret && $sig ) {
        $parts     = [];
        foreach ( explode(',', $sig) as $part ) {
            list($k, $v) = explode('=', $part, 2);
            $parts[$k][] = $v;
        }
        $timestamp = $parts['t'][0] ?? 0;
        $computed  = hash_hmac( 'sha256', $timestamp . '.' . $payload, $secret );
        $received  = $parts['v1'][0] ?? '';
        if ( ! hash_equals($computed, $received) ) {
            return new WP_Error( 'invalid_signature', 'Signature mismatch', ['status' => 400] );
        }
    }

    $event = json_decode( $payload, true );
    $type  = $event['type'] ?? '';
    $obj   = $event['data']['object'] ?? [];

    switch ( $type ) {
        case 'checkout.session.completed':
            // Determinar si es suscripción o créditos extra
            $mode = $obj['mode'] ?? 'payment';
            if ( $mode === 'subscription' ) {
                update_option( 'mira_subscription_status', 'active' );
                update_option( 'mira_subscription_id', $obj['subscription'] ?? '' );
                update_option( 'mira_customer_id', $obj['customer'] ?? '' );
            } elseif ( $mode === 'payment' ) {
                // Pack de créditos — mapear por amount
                $amount  = (int)( $obj['amount_total'] ?? 0 );
                $credits = 0;
                if ( $amount <= 1500 ) $credits = 50;
                elseif ( $amount <= 2800 ) $credits = 150;
                else $credits = 400;
                update_option( 'mira_paid_credits', (int)get_option('mira_paid_credits', 0) + $credits );
            }
            break;

        case 'customer.subscription.updated':
            $status = $obj['status'] ?? 'none';
            update_option( 'mira_subscription_status', $status );
            $plan_name = $obj['items']['data'][0]['price']['product'] ?? '';
            update_option( 'mira_subscription_plan', $plan_name );
            $end = $obj['current_period_end'] ?? 0;
            if ( $end ) update_option( 'mira_subscription_end', date('d/m/Y', $end) );
            break;

        case 'customer.subscription.deleted':
            update_option( 'mira_subscription_status', 'cancelled' );
            break;
    }

    return ['received' => true];
}

function mira_optimize_image( WP_REST_Request $req ) {
    $image_url = sanitize_url( $req->get_param('image_url') );
    $post_id   = (int) $req->get_param('post_id');
    $dalle_key = get_option( 'mira_dalle_key' );
    $cat_type  = get_post_meta( $post_id, '_mira_category_type', true ) ?: 'clothing';

    if ( ! $dalle_key ) return new WP_Error( 'no_key', 'No DALL-E key configured', ['status' => 400] );
    if ( ! $image_url ) return new WP_Error( 'no_image', 'No image URL', ['status' => 400] );

    // Prompt adaptado al tipo de producto
    $prompts = [
        'clothing' => 'Fashion product photo of this garment on a neutral mannequin, white background, flat lay style, professional studio lighting, no model face visible, full garment visible',
        'glasses'  => 'Product photo of these glasses on a clean white surface, professional studio lighting, white background, frontal view',
        'jewelry'  => 'Luxury product photo of this jewelry piece on white marble surface, professional studio lighting, macro detail shot',
        'bag'      => 'Fashion product photo of this bag on white background, professional studio lighting, structured view showing all details',
        'other'    => 'Professional product photo on white background, clean studio lighting, full product visible',
    ];
    $prompt = $prompts[$cat_type] ?? $prompts['clothing'];

    // Llamada a DALL-E 3 Variations (imágenes)
    $response = wp_remote_post( 'https://api.openai.com/v1/images/generate', [
        'headers' => [
            'Authorization' => 'Bearer ' . $dalle_key,
            'Content-Type'  => 'application/json',
        ],
        'body'    => json_encode([
            'model'  => 'dall-e-3',
            'prompt' => $prompt . '. Based on product image: ' . $image_url,
            'n'      => 1,
            'size'   => '1024x1024',
        ]),
        'timeout' => 60,
    ]);

    if ( is_wp_error($response) ) {
        return new WP_Error( 'api_error', $response->get_error_message(), ['status' => 500] );
    }

    $body = json_decode( wp_remote_retrieve_body($response), true );
    $url  = $body['data'][0]['url'] ?? '';

    if ( ! $url ) {
        return new WP_Error( 'no_url', 'No image generated', ['status' => 500] );
    }

    // Guardar como imagen de IA del producto
    update_post_meta( $post_id, '_hunix_hidden_ai_img', $url );

    return ['success' => true, 'url' => $url];
}

// ==========================================
// 7. SHORTCODES
// ==========================================
add_shortcode( 'hunix_gallery', 'mira_render_gallery' );
function mira_render_gallery( $atts ) {
    $atts  = shortcode_atts( ['limit' => -1, 'columns' => 3], $atts );
    $query = new WP_Query([
        'post_type' => 'hunix_outfit', 'posts_per_page' => $atts['limit'], 'post_status' => 'publish',
    ]);

    if ( ! $query->have_posts() ) return '<p>No hay outfits disponibles.</p>';

    $bg  = get_option( 'mira_color_brand', '#1a1917' );
    $col = get_option( 'mira_color_text', '#FFFFFF' );
    $r   = (int) get_option( 'mira_btn_radius', 8 );

    ob_start();
    echo '<div class="hunix-gallery-grid" style="display:grid; grid-template-columns:repeat(' . $atts['columns'] . ',1fr); gap:20px;">';
    while ( $query->have_posts() ) {
        $query->the_post();
        $id    = get_the_ID();
        $title = get_the_title();
        $thumb = get_the_post_thumbnail_url( $id, 'large' );
        $ai    = get_post_meta( $id, '_hunix_hidden_ai_img', true );
        $img   = ! empty($ai) ? $ai : $thumb;
        $type  = get_post_meta( $id, '_mira_category_type', true ) ?: 'clothing';
        if ( empty($img) ) continue;
        echo '<div class="hunix-outfit-card" style="border:1px solid #eee; border-radius:10px; overflow:hidden; background:#fff;">';
        echo '<div style="height:300px; background-image:url(' . esc_url($img) . '); background-size:cover; background-position:center;"></div>';
        echo '<div style="padding:14px;">';
        echo '<h4 style="margin:0 0 10px;">' . esc_html($title) . '</h4>';
        echo '<button class="hunix-gallery-btn" data-img="' . esc_url($img) . '" data-title="' . esc_attr($title) . '" data-type="' . esc_attr($type) . '" style="width:100%; background:' . esc_attr($bg) . '; color:' . esc_attr($col) . '; border:none; padding:10px; border-radius:' . $r . 'px; cursor:pointer; font-weight:bold;">✨ PROBAR OUTFIT</button>';
        echo '</div></div>';
    }
    echo '</div>';
    wp_reset_postdata();
    return ob_get_clean();
}

add_shortcode( 'hunix_tryon_page', 'mira_render_tryon_page' );
function mira_render_tryon_page( $atts ) {
    $atts  = shortcode_atts( ['title' => 'Probador Virtual', 'subtitle' => 'Crea tu perfil y prueba outfits con IA', 'columns' => 3, 'limit' => -1], $atts );
    $bg    = get_option( 'mira_color_brand', '#1a1917' );
    $col   = get_option( 'mira_color_text', '#FFFFFF' );
    $r     = (int) get_option( 'mira_btn_radius', 8 );

    ob_start(); ?>
    <div class="hunix-tryon" data-hunix-tryon-page>
        <section class="hunix-tryon-hero">
            <div class="hunix-tryon-hero-inner">
                <h1 class="hunix-tryon-title"><?php echo esc_html($atts['title']); ?></h1>
                <p class="hunix-tryon-subtitle"><?php echo esc_html($atts['subtitle']); ?></p>
                <div class="hunix-tryon-actions">
                    <button type="button" class="hunix-tryon-btn hunix-tryon-btn-primary" data-hx-open-profile style="background:<?php echo esc_attr($bg); ?>; color:<?php echo esc_attr($col); ?>; border-radius:<?php echo $r; ?>px;">Configurar mi perfil</button>
                    <button type="button" class="hunix-tryon-btn hunix-tryon-btn-secondary" data-hx-scroll="#hunix-tryon-outfits">Ver outfits ↓</button>
                </div>
                <div class="hunix-tryon-status" data-hx-profile-status></div>
            </div>
        </section>
        <section id="hunix-tryon-outfits" class="hunix-tryon-section">
            <h2 class="hunix-tryon-section-title">Outfits disponibles</h2>
            <?php echo do_shortcode('[hunix_gallery columns="' . intval($atts['columns']) . '" limit="' . intval($atts['limit']) . '"]'); ?>
        </section>
    </div>
    <?php return ob_get_clean();
}

// ==========================================
// VERIFICACIÓN DE DEPENDENCIAS
// ==========================================
add_action( 'admin_init', function() {
    if ( ! class_exists('WooCommerce') && current_user_can('activate_plugins') ) {
        add_action( 'admin_notices', function() {
            echo '<div class="notice notice-error"><p>⚠️ <strong>Mira IA:</strong> Requiere WooCommerce activo.</p></div>';
        });
    }
});
