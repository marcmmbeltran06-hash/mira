jQuery(document).ready(function($) {
    
    // VARIABLES
    let defaultImage = $('#hx-default-img').val();
    let currentImage = defaultImage;
    if($('#hx-single-img').length > 0) currentImage = $('#hx-single-img').val();
    
    let userBlob = null;
    let stream = null;
    const submittedColors = new Set(); 
    let btnInterval = null;

    // ===============================================
    // 0. ANIMACIÓN DE TEXTO
    // ===============================================
    function startButtonRotation() {
        if(btnInterval) clearInterval(btnInterval);
        const texts = [hx_vars.btn_def, "📸 MIRA CÓMO TE QUEDA"];
        let idx = 0;
        btnInterval = setInterval(() => {
            const btn = $('#hunix-btn');
            if(!btn.prop('disabled')) {
                if($('#hx-ai-selector').val() && $('#hx-ai-selector').val() !== 'default') return;
                idx = (idx + 1) % texts.length;
                $('#hx-btn-text').fadeOut(200, function() { $(this).text(texts[idx]).fadeIn(200); });
            }
        }, 3000);
    }

    // ===============================================
    // 1. SELECTOR Y ESTADOS
    // ===============================================
    function updateButtonState() {
        const selector = $('#hx-ai-selector');
        const btn = $('#hunix-btn');
        const txt = $('#hx-btn-text');
        
        if (selector.length === 0) {
            if (submittedColors.has('single')) {
                btn.css({'background': '#4CAF50', 'cursor':'not-allowed', 'opacity':'0.8'}).prop('disabled', true);
                txt.text('✅ YA ENVIADO');
            } else {
                btn.css({'background': hx_vars.brand_color, 'cursor':'pointer', 'opacity':'1'}).prop('disabled', false);
            }
            return;
        }

        const selectedVal = selector.val();
        if (selectedVal === 'default') {
            btn.css({'background': '#999', 'cursor':'not-allowed', 'opacity':'0.6'}).prop('disabled', true);
            txt.text('👆 ELIGE UN COLOR PRIMERO');
            return;
        }
        if (submittedColors.has(selectedVal)) {
            btn.css({'background': '#4CAF50', 'cursor':'not-allowed', 'opacity':'0.8'}).prop('disabled', true);
            txt.text('✅ YA ENVIADO (' + selectedVal.toUpperCase() + ')');
            return;
        }
        
        btn.css({'background': hx_vars.brand_color, 'cursor':'pointer', 'opacity':'1'}).prop('disabled', false);
        if (selectedVal === 'all') txt.text('🚀 PROBAR TODOS LOS COLORES');
        else txt.text('✨ PROBAR EN ' + selectedVal.toUpperCase());
    }

    $('#hx-ai-selector').change(function() {
        const selected = $(this).val();
        const selectedImg = $(this).find(':selected').data('img');
        if (selected === 'all') currentImage = 'all'; 
        else if (selected === 'default') currentImage = defaultImage;
        else currentImage = selectedImg;
        updateButtonState();
    });

    // ===============================================
    // 2. MODAL LOGIC
    // ===============================================
    const openModal = () => $('#hunix-modal-wrap').fadeIn().css('display','flex');
    const closeModal = () => { $('#hunix-modal-wrap').fadeOut(); stopCam(); };

    $('#hunix-float').click(function(){
        if(localStorage.getItem('hx_ready') === '1') {
            $('#hx-step-1').hide(); $('#hx-step-2').hide(); $('#hx-step-ready').show(); openModal();
        } else {
            $('#hx-step-ready').hide(); $('#hx-step-1').show(); openModal();
        }
    });
    $('#hx-edit-profile').click(function(e){ e.preventDefault(); $('#hx-step-ready').fadeOut(200, function(){ $('#hx-step-1').fadeIn(); }); });
    $('#hx-close-ready').click(closeModal);

    $(document).on('click', '[data-hx-open-profile]', function(e){
        e.preventDefault();
        if(localStorage.getItem('hx_ready') === '1') {
            $('#hx-step-1').hide(); $('#hx-step-2').hide(); $('#hx-step-ready').show(); openModal();
        } else {
            $('#hx-step-ready').hide(); $('#hx-step-1').show(); openModal();
        }
    });

    $(document).on('click', '[data-hx-scroll]', function(e){
        e.preventDefault();
        const sel = $(this).attr('data-hx-scroll');
        if(!sel) return;
        const $target = $(sel);
        if(!$target.length) return;
        $('html,body').animate({scrollTop: $target.offset().top - 80}, 450);
    });

    // ===============================================
    // 3. FUNCIONES GENERALES
    // ===============================================
    // TOAST AUMENTADO A 6 SEGUNDOS PARA QUE DE TIEMPO A LEER
    function toast(msg, icon='ℹ️') {
        $('#hx-t-msg').text(msg); $('#hx-t-icon').text(icon);
        $('#hx-toast').stop(true, true).fadeIn().css('display','flex').delay(6000).fadeOut();
    }
    
    $('#hx-shortcut').click(function(){ $('#hx-name').focus(); $('details').removeAttr('open'); });

    function checkProfile() {
        if(localStorage.getItem('hx_ready') === '1') {
            $('#hunix-container').show(); $('#hx-dot').show();
            $('#hunix-btn').off('click').on('click', handleGeneration);
            $('#hx-name').val(localStorage.getItem('hx_name')); $('#hx-tel').val(localStorage.getItem('hx_tel'));
            updateButtonState();
        } else {
            $('#hunix-container').show();
            if($('#hx-ai-selector').length === 0) $('#hx-btn-text').text('👋 CREA TU PERFIL PRIMERO');
            $('#hunix-btn').off('click').on('click', openModal);
        }
        updateTryonPageStatus();
    }

    function updateTryonPageStatus() {
        const el = $('[data-hx-profile-status]');
        if(!el.length) return;
        const ready = localStorage.getItem('hx_ready') === '1';
        const name = localStorage.getItem('hx_name') || '';
        if(ready) el.text('✅ Perfil activo' + (name ? (' — ' + name) : '') + '. Ya puedes probar outfits.');
        else el.text('👤 Aún no tienes perfil. Pulsa “Configurar mi perfil” para subir tu foto.');
        if($('body').hasClass('hunix-tryon-page') || $('[data-hunix-tryon-page]').length) $('#hunix-float').hide();
    }

    function handleGeneration(e) {
        e.preventDefault();
        if(localStorage.getItem('hx_ready') !== '1') { $('#hx-step-ready').hide(); $('#hx-step-1').show(); openModal(); return; }
        let selectedVal = 'single';
        if($('#hx-ai-selector').length > 0) {
            selectedVal = $('#hx-ai-selector').val();
            if(selectedVal === 'default') return toast('Por favor, elige un color primero', '🎨');
        }
        if(submittedColors.has(selectedVal)) return toast('Ya solicitado. Espera unos segundos.', '⏳');
        if(currentImage === 'all') runTryAll(); else sendToMake(currentImage, selectedVal); 
    }

    $('#hx-save').click(async function(){
        const btn = $(this); const name = $('#hx-name').val(); const tel = $('#hx-tel').val(); const file = document.getElementById('hx-file').files[0]; const policy = $('#hx-policy').is(':checked');
        if(!name) return toast('Falta tu Nombre', '👤'); if(!tel) return toast('Falta tu Teléfono', '📱'); if(!policy) return toast('Debes aceptar la política', '⚠️'); if(!file && !userBlob && !localStorage.getItem('hx_img_url')) return toast('Falta tu Foto', '📷');
        btn.text('Guardando...').prop('disabled',true);
        try {
            let imgUrl = localStorage.getItem('hx_img_url');
            if(file || userBlob) {
                const fd = new FormData(); fd.append('file', file || userBlob);
                const res = await fetch(hx_vars.api_up, {method:'POST', headers:{'X-WP-Nonce':hx_vars.nonce}, body:fd});
                const data = await res.json(); if(!data.success) throw new Error(); imgUrl = data.url;
            }
            const fullTel = $('#hx-pre').val() + tel;
            localStorage.setItem('hx_name', name); localStorage.setItem('hx_tel', tel); localStorage.setItem('hx_full_tel', fullTel); localStorage.setItem('hx_img_url', imgUrl); localStorage.setItem('hx_ready', '1');
            if(hx_vars.wh_reg) { fetch(hx_vars.wh_reg, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({type:'registro', name: name, phone: fullTel, body_image: imgUrl})}); }
            fetch(hx_vars.api_st, {method:'POST', headers:{'X-WP-Nonce':hx_vars.nonce}, body:JSON.stringify({type:'user'})});
            updateTryonPageStatus();
            $('#hx-step-1').hide(); $('#hx-step-2').fadeIn();
        } catch(e) { toast('Error al subir', '❌'); }
        btn.text('GUARDAR PERFIL').prop('disabled',false);
    });

    $('#hx-finish').click(function(){
        closeModal(); checkProfile(); const btn = $('#hunix-btn');
        btn.prop('disabled', true).css({'background':'#666', 'cursor':'wait'});
        btn.find('#hx-btn-text').text('⏳ PREPARANDO PROBADOR...');
        $('html,body').animate({scrollTop:$('#hunix-container').offset().top - 200}, 500);
        setTimeout(() => { updateButtonState(); toast("¡Listo! Ya puedes probarte la ropa.", "✅"); }, 5000);
    });

    // ===============================================
    // ENVÍOS (AQUÍ ESTÁ EL CAMBIO DEL MENSAJE)
    // ===============================================
    async function sendToMake(imgUrl, colorName) {
        const btn = $('#hunix-btn'); const originalTxt = btn.find('#hx-btn-text').text();
        btn.prop('disabled',true).find('#hx-btn-text').text('ENVIANDO...');
        $('#hx-loader-wrap').show(); $('#hx-loader').css('width','60%');
        try {
            await fetch(hx_vars.wh_gen, { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({type:'solicitud', phone: localStorage.getItem('hx_full_tel'), name: localStorage.getItem('hx_name'), product_image: imgUrl, product_link: hx_vars.prod_link})});
            fetch(hx_vars.api_st, {method:'POST', headers:{'X-WP-Nonce':hx_vars.nonce}, body:JSON.stringify({type:'try'})});
            $('#hx-loader').css('width','100%');
            
            // NUEVO MENSAJE CON AVISO DE TIEMPO
            toast('¡Enviado! Tu foto llegará en unos 2 minutos a tu WhatsApp.', '🚀');
            
            submittedColors.add(colorName);
            setTimeout(()=> { $('#hx-loader').css('width','0%'); $('#hx-loader-wrap').hide(); updateButtonState(); }, 1000);
        } catch(e) { toast('Error de conexión', '❌'); btn.prop('disabled',false).find('#hx-btn-text').text(originalTxt); }
    }

    async function runTryAll() {
        const btn = $('#hunix-btn'); btn.prop('disabled',true).find('#hx-btn-text').text('ENVIANDO COLORES...');
        $('#hx-loader-wrap').show();
        let options = [];
        $('#hx-ai-selector option').each(function(){ let val = $(this).val(); let url = $(this).data('img'); if(val !== 'default' && val !== 'all' && !submittedColors.has(val)) options.push({val:val, url:url}); });
        if(options.length===0){ toast('Ya has probado todo.', '✅'); $('#hx-loader-wrap').hide(); updateButtonState(); return;}
        toast('Enviando ' + options.length + ' looks...', '🚀');
        for (let i=0; i<options.length; i++) {
            let pct = ((i+1)/options.length)*100; $('#hx-loader').css('width', pct+'%');
            await fetch(hx_vars.wh_gen, {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({type:'solicitud', phone: localStorage.getItem('hx_full_tel'), name: localStorage.getItem('hx_name'), product_image: options[i].url, product_link: hx_vars.prod_link})});
            submittedColors.add(options[i].val);
            await new Promise(r => setTimeout(r, 1500));
        }
        $('#hx-loader').css('width','0%'); $('#hx-loader-wrap').hide(); btn.prop('disabled',false).find('#hx-btn-text').text('¡TODO ENVIADO!');
        
        // NUEVO MENSAJE PARA "PROBAR TODOS"
        toast('¡Todo enviado! Tus fotos llegarán en unos 2-3 minutos a tu WhatsApp.', '🚀');
        
        setTimeout(() => updateButtonState(), 2000);
    }

    // EXTRA UI
    $('#tab-up').click(function(){ $(this).css({'background':'#fff','color':'#000','box-shadow':'0 2px 5px rgba(0,0,0,0.1)'}); $('#tab-cam').css({'background':'transparent','color':'#999','box-shadow':'none'}); $('#box-up').show(); $('#box-cam').hide(); stopCam(); });
    $('#tab-cam').click(function(){ $(this).css({'background':'#fff','color':'#000','box-shadow':'0 2px 5px rgba(0,0,0,0.1)'}); $('#tab-up').css({'background':'transparent','color':'#999','box-shadow':'none'}); $('#box-up').hide(); $('#box-cam').show(); startCam(); });
    $('#hx-file').change(function(e){ if(e.target.files[0]) { $('#preview-up').css('background-image', `url(${URL.createObjectURL(e.target.files[0])})`); userBlob = null; } });
    async function startCam() { try { stream = await navigator.mediaDevices.getUserMedia({video:{facingMode:'user'}}); document.getElementById('hx-vid').srcObject=stream; } catch(e){ toast('Error de cámara', '🚫'); } }
    function stopCam() { if(stream) stream.getTracks().forEach(t=>t.stop()); }
    $('#hx-snap').click(function(){ const v=document.getElementById('hx-vid'); const c=document.getElementById('hx-can'); c.width=v.videoWidth; c.height=v.videoHeight; c.getContext('2d').drawImage(v,0,0); c.toBlob(b=>{ userBlob=b; $('#preview-cam').css('background-image', `url(${URL.createObjectURL(b)})`).show(); $('#hx-retake').show(); $('#hx-snap').hide(); }, 'image/jpeg', 0.85); });
    $('#hx-retake').click(()=>{ $('#preview-cam').hide(); $('#hx-retake').hide(); $('#hx-snap').show(); userBlob=null; });
    $('#hx-close').click(closeModal); $('#hunix-overlay').click((e)=>{ if(e.target.id === 'hunix-overlay') closeModal(); }); $('#hx-reset').click((e)=>{ e.preventDefault(); $('#hx-step-2').hide(); $('#hx-step-1').fadeIn(); });
    
    checkProfile();
    startButtonRotation();

    // ===============================================
    // 6. GALLERY LOGIC
    // ===============================================
    $(document).on('click', '.hunix-gallery-btn', function(e) {
        e.preventDefault();
        if(localStorage.getItem('hx_ready') !== '1') { 
            $('#hx-step-ready').hide(); 
            $('#hx-step-1').show(); 
            openModal(); 
            return; 
        }
        
        const imgUrl = $(this).data('img');
        const title = $(this).data('title');
        sendToMakeFromGallery(imgUrl, title);
    });

    async function sendToMakeFromGallery(imgUrl, title) {
        $('#hx-gallery-loader').css('display', 'flex');
        try {
            await fetch(hx_vars.wh_gen, { 
                method:'POST', 
                headers:{'Content-Type':'application/json'}, 
                body:JSON.stringify({
                    type:'solicitud', 
                    phone: localStorage.getItem('hx_full_tel'), 
                    name: localStorage.getItem('hx_name'), 
                    product_image: imgUrl, 
                    product_link: window.location.href 
                })
            });
            fetch(hx_vars.api_st, {method:'POST', headers:{'X-WP-Nonce':hx_vars.nonce}, body:JSON.stringify({type:'try'})});
            
            toast('¡Enviado! Tu foto con "' + title + '" llegará en unos 2 minutos a tu WhatsApp.', '🚀');
        } catch(e) { 
            toast('Error de conexión', '❌'); 
        }
        $('#hx-gallery-loader').hide();
    }
});
